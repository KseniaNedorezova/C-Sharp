﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabCalculator
{
    internal class CalcOperations
    {
        public enum Operation
        {
            plus,
            minus,
            multiplication,
            division
        }

        private double firstNumber = 0.0;
        private double memory = 0.0;
        private Operation operation;
        public bool blockedbutton = true;

        public void SaveOperation(Operation operation)
        {
            this.operation = operation;
        }
        public Operation GetOperation()
        {
            return this.operation;
        }
        public void UnblockedButtons()
        {
            blockedbutton = true;
        }
        public void SaveFirstNumber(double firstNumber)
        {
            this.firstNumber = firstNumber;
        }

        public void cleanFirstNumber()
        {
            firstNumber = 0.0;
        }

        public double Sum(double secondNumber)
        {
            return firstNumber + secondNumber;
        }
        public double Substr(double secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public double Multiplication(double secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public double Division(double secondNumber)
        {
            if (secondNumber == 0)
            {
                MessageBox.Show("Division by 0!");
                return firstNumber;
            }
            else
                return firstNumber / secondNumber;
        }

        public double Sqrt()
        {
            if (firstNumber < 0)
            {
                MessageBox.Show("Root of negative number");
                return firstNumber;
            }
            else
            {
                return Math.Sqrt(firstNumber);
            }
        }

        public string Square(string number)
        {
            return Math.Pow(Convert.ToDouble(number), 2.0).ToString();
        }

        public string Sin(string number)
        {
            return Math.Sin(Convert.ToDouble(number)).ToString();
        }
        public string Cos(string number)
        {
            return Math.Cos(Convert.ToDouble(number)).ToString();
        }
        public string Tg(string number)
        {
            return Math.Tan(Convert.ToDouble(number)).ToString();
        }
        public string Ctg(string number)
        {
            if (Math.Tan(Convert.ToDouble(number)) == 0)
            {
                MessageBox.Show("Tangent equal 0. Cotanget doesn't exist.");
                return number;
            }
            else
                return (1/Math.Tan(Convert.ToDouble(number))).ToString();
        }

        public string DivisionOnX(string number)
        {
            if (Convert.ToDouble(number) == 0)
            {
                MessageBox.Show("Division by 0.");        
                return number;
            }
            else
                return (1 / Convert.ToDouble(number)).ToString();
        }

        public string Logarithm10(string number)
        {
            if (Convert.ToDouble(number) <= 0)
            {
                MessageBox.Show("Logarithm of a negative number or 0.");
                return number;
            }
            else
                return (Math.Log10(Convert.ToDouble(number))).ToString();
        }
        public string Ln(string number)
        {
            if (Convert.ToDouble(number) <= 0)
            {
                MessageBox.Show("Logarithm of a negative number or 0.");
                return number;
            }
            else
                return (Math.Log(Convert.ToDouble(number))).ToString();
        }
        public string Factorial(string number)
        {
            if (Convert.ToDouble(number) < 0)
            {
                MessageBox.Show("Factorial of a negative number.");
                return number;
            }
            else
            {
                double fact = 1;
                for (int i = 1; i <= Convert.ToDouble(number); i++)
                    fact *= (double)i;

                return fact.ToString();
            }
        }
        public string btnSqrt(string number)
        {
            if (number != " ")
            {
                SaveFirstNumber(Convert.ToDouble(number));
                if (Convert.ToDouble(number) >= 0) 
                    number = Sqrt().ToString(); 
                else
                    number = " "; 
                cleanFirstNumber();
                UnblockedButtons();
            }
            return number;
        }

        public string Equal(string secondNumber)
        {
            if (secondNumber != " ")
            {
                if (blockedbutton == false)
                {
                    switch (GetOperation())
                    {
                        case Operation.plus:
                            return Sum(Convert.ToDouble(secondNumber)).ToString();
                        case Operation.minus:
                            return Substr(Convert.ToDouble(secondNumber)).ToString();
                        case Operation.multiplication:
                            return Multiplication(Convert.ToDouble(secondNumber)).ToString();
                        case Operation.division:
                            return Division(Convert.ToDouble(secondNumber)).ToString();

                    }
                }
            }
            return "0";
        }

        public string MR()
        {
            return ShowMemory().ToString();
        }

        public void SetNumberInMemory(double number)
        {
            this.memory = number;
        }
        public double ShowMemory()
        {
            return memory;
        }

        public void MemoryClear()
        {
            memory = 0;
        }
        public void btnClear()
        {
            MemoryClear();
            cleanFirstNumber();
            UnblockedButtons();
        }

        public void SaveFirstOper(string number)
        {
            if (number != " ")
            {
                SaveFirstNumber(Convert.ToDouble(number));
                blockedbutton = false;
            }
        }
    }
}
