﻿namespace LabCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnSqrt = new System.Windows.Forms.Button();
            this.btnDivOnX = new System.Windows.Forms.Button();
            this.btnSin = new System.Windows.Forms.Button();
            this.btnLn = new System.Windows.Forms.Button();
            this.btnCos = new System.Windows.Forms.Button();
            this.btnLog2 = new System.Windows.Forms.Button();
            this.btnTg = new System.Windows.Forms.Button();
            this.btnLog10 = new System.Windows.Forms.Button();
            this.btnCtg = new System.Windows.Forms.Button();
            this.btnSquaring = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnDot = new System.Windows.Forms.Button();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnPM = new System.Windows.Forms.Button();
            this.btnMinus = new System.Windows.Forms.Button();
            this.btnMultiplication = new System.Windows.Forms.Button();
            this.btnEqual = new System.Windows.Forms.Button();
            this.btnPlus = new System.Windows.Forms.Button();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnMemorySave = new System.Windows.Forms.Button();
            this.btnMemoryRead = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnSqrt);
            this.flowLayoutPanel1.Controls.Add(this.btnDivOnX);
            this.flowLayoutPanel1.Controls.Add(this.btnSin);
            this.flowLayoutPanel1.Controls.Add(this.btnLn);
            this.flowLayoutPanel1.Controls.Add(this.btnCos);
            this.flowLayoutPanel1.Controls.Add(this.btnLog2);
            this.flowLayoutPanel1.Controls.Add(this.btnTg);
            this.flowLayoutPanel1.Controls.Add(this.btnLog10);
            this.flowLayoutPanel1.Controls.Add(this.btnCtg);
            this.flowLayoutPanel1.Controls.Add(this.btnSquaring);
            this.flowLayoutPanel1.Controls.Add(this.flowLayoutPanel2);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(1, 177);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(274, 264);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // btnSqrt
            // 
            this.btnSqrt.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSqrt.Location = new System.Drawing.Point(3, 3);
            this.btnSqrt.Name = "btnSqrt";
            this.btnSqrt.Size = new System.Drawing.Size(130, 46);
            this.btnSqrt.TabIndex = 0;
            this.btnSqrt.Text = "sqrt";
            this.btnSqrt.UseVisualStyleBackColor = false;
            this.btnSqrt.Click += new System.EventHandler(this.btnSqrt_Click);
            // 
            // btnDivOnX
            // 
            this.btnDivOnX.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDivOnX.Location = new System.Drawing.Point(139, 3);
            this.btnDivOnX.Name = "btnDivOnX";
            this.btnDivOnX.Size = new System.Drawing.Size(130, 46);
            this.btnDivOnX.TabIndex = 1;
            this.btnDivOnX.Text = "1/x";
            this.btnDivOnX.UseVisualStyleBackColor = false;
            this.btnDivOnX.Click += new System.EventHandler(this.btnDivOnX_Click);
            // 
            // btnSin
            // 
            this.btnSin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSin.Location = new System.Drawing.Point(3, 55);
            this.btnSin.Name = "btnSin";
            this.btnSin.Size = new System.Drawing.Size(130, 46);
            this.btnSin.TabIndex = 2;
            this.btnSin.Text = "sin";
            this.btnSin.UseVisualStyleBackColor = false;
            this.btnSin.Click += new System.EventHandler(this.btnSin_Click);
            // 
            // btnLn
            // 
            this.btnLn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLn.Location = new System.Drawing.Point(139, 55);
            this.btnLn.Name = "btnLn";
            this.btnLn.Size = new System.Drawing.Size(130, 46);
            this.btnLn.TabIndex = 3;
            this.btnLn.Text = "ln";
            this.btnLn.UseVisualStyleBackColor = false;
            this.btnLn.Click += new System.EventHandler(this.btnLn_Click);
            // 
            // btnCos
            // 
            this.btnCos.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCos.Location = new System.Drawing.Point(3, 107);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(130, 46);
            this.btnCos.TabIndex = 4;
            this.btnCos.Text = "cos";
            this.btnCos.UseVisualStyleBackColor = false;
            this.btnCos.Click += new System.EventHandler(this.btnCos_Click);
            // 
            // btnLog2
            // 
            this.btnLog2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLog2.Location = new System.Drawing.Point(139, 107);
            this.btnLog2.Name = "btnLog2";
            this.btnLog2.Size = new System.Drawing.Size(130, 46);
            this.btnLog2.TabIndex = 5;
            this.btnLog2.Text = "!";
            this.btnLog2.UseVisualStyleBackColor = false;
            this.btnLog2.Click += new System.EventHandler(this.btnLog2_Click);
            // 
            // btnTg
            // 
            this.btnTg.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTg.Location = new System.Drawing.Point(3, 159);
            this.btnTg.Name = "btnTg";
            this.btnTg.Size = new System.Drawing.Size(130, 46);
            this.btnTg.TabIndex = 6;
            this.btnTg.Text = "tg";
            this.btnTg.UseVisualStyleBackColor = false;
            this.btnTg.Click += new System.EventHandler(this.btnTg_Click);
            // 
            // btnLog10
            // 
            this.btnLog10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLog10.Location = new System.Drawing.Point(139, 159);
            this.btnLog10.Name = "btnLog10";
            this.btnLog10.Size = new System.Drawing.Size(130, 46);
            this.btnLog10.TabIndex = 1;
            this.btnLog10.Text = "log10";
            this.btnLog10.UseVisualStyleBackColor = false;
            this.btnLog10.Click += new System.EventHandler(this.btnLog10_Click);
            // 
            // btnCtg
            // 
            this.btnCtg.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCtg.Location = new System.Drawing.Point(3, 211);
            this.btnCtg.Name = "btnCtg";
            this.btnCtg.Size = new System.Drawing.Size(130, 46);
            this.btnCtg.TabIndex = 7;
            this.btnCtg.Text = "ctg";
            this.btnCtg.UseVisualStyleBackColor = false;
            this.btnCtg.Click += new System.EventHandler(this.btnCtg_Click);
            // 
            // btnSquaring
            // 
            this.btnSquaring.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSquaring.Location = new System.Drawing.Point(139, 211);
            this.btnSquaring.Name = "btnSquaring";
            this.btnSquaring.Size = new System.Drawing.Size(130, 46);
            this.btnSquaring.TabIndex = 8;
            this.btnSquaring.Text = "x^2";
            this.btnSquaring.UseVisualStyleBackColor = false;
            this.btnSquaring.Click += new System.EventHandler(this.btnSquaring_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 263);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel2.TabIndex = 9;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.btn7);
            this.flowLayoutPanel3.Controls.Add(this.btn8);
            this.flowLayoutPanel3.Controls.Add(this.btn9);
            this.flowLayoutPanel3.Controls.Add(this.btn4);
            this.flowLayoutPanel3.Controls.Add(this.btn5);
            this.flowLayoutPanel3.Controls.Add(this.btn6);
            this.flowLayoutPanel3.Controls.Add(this.btn1);
            this.flowLayoutPanel3.Controls.Add(this.btn2);
            this.flowLayoutPanel3.Controls.Add(this.btn3);
            this.flowLayoutPanel3.Controls.Add(this.btn0);
            this.flowLayoutPanel3.Controls.Add(this.btnDot);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(281, 232);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(411, 209);
            this.flowLayoutPanel3.TabIndex = 1;
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(3, 3);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(130, 46);
            this.btn7.TabIndex = 0;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(139, 3);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(130, 46);
            this.btn8.TabIndex = 1;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(275, 3);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(130, 46);
            this.btn9.TabIndex = 2;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(3, 55);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(130, 46);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(139, 55);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(130, 46);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(275, 55);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(130, 46);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(3, 107);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(130, 46);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(139, 107);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(130, 46);
            this.btn2.TabIndex = 7;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(275, 107);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(130, 46);
            this.btn3.TabIndex = 8;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(3, 159);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(266, 46);
            this.btn0.TabIndex = 9;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnDot
            // 
            this.btnDot.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDot.Location = new System.Drawing.Point(275, 159);
            this.btnDot.Name = "btnDot";
            this.btnDot.Size = new System.Drawing.Size(130, 46);
            this.btnDot.TabIndex = 11;
            this.btnDot.Text = "•";
            this.btnDot.UseVisualStyleBackColor = false;
            this.btnDot.Click += new System.EventHandler(this.btnDot_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.btnDivision);
            this.flowLayoutPanel4.Controls.Add(this.btnPM);
            this.flowLayoutPanel4.Controls.Add(this.btnMinus);
            this.flowLayoutPanel4.Controls.Add(this.btnMultiplication);
            this.flowLayoutPanel4.Controls.Add(this.btnEqual);
            this.flowLayoutPanel4.Controls.Add(this.btnPlus);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(698, 287);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(276, 154);
            this.flowLayoutPanel4.TabIndex = 2;
            // 
            // btnDivision
            // 
            this.btnDivision.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDivision.Location = new System.Drawing.Point(3, 3);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(130, 46);
            this.btnDivision.TabIndex = 1;
            this.btnDivision.Text = "/";
            this.btnDivision.UseVisualStyleBackColor = false;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);
            // 
            // btnPM
            // 
            this.btnPM.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPM.Location = new System.Drawing.Point(139, 3);
            this.btnPM.Name = "btnPM";
            this.btnPM.Size = new System.Drawing.Size(130, 46);
            this.btnPM.TabIndex = 2;
            this.btnPM.Text = "+/-";
            this.btnPM.UseVisualStyleBackColor = false;
            this.btnPM.Click += new System.EventHandler(this.btnPM_Click);
            // 
            // btnMinus
            // 
            this.btnMinus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMinus.Location = new System.Drawing.Point(3, 55);
            this.btnMinus.Name = "btnMinus";
            this.btnMinus.Size = new System.Drawing.Size(130, 46);
            this.btnMinus.TabIndex = 3;
            this.btnMinus.Text = "-";
            this.btnMinus.UseVisualStyleBackColor = false;
            this.btnMinus.Click += new System.EventHandler(this.btnMinus_Click);
            // 
            // btnMultiplication
            // 
            this.btnMultiplication.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMultiplication.Location = new System.Drawing.Point(139, 55);
            this.btnMultiplication.Name = "btnMultiplication";
            this.btnMultiplication.Size = new System.Drawing.Size(130, 46);
            this.btnMultiplication.TabIndex = 4;
            this.btnMultiplication.Text = "*";
            this.btnMultiplication.UseVisualStyleBackColor = false;
            this.btnMultiplication.Click += new System.EventHandler(this.btnMultiplication_Click);
            // 
            // btnEqual
            // 
            this.btnEqual.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEqual.Location = new System.Drawing.Point(3, 107);
            this.btnEqual.Name = "btnEqual";
            this.btnEqual.Size = new System.Drawing.Size(130, 46);
            this.btnEqual.TabIndex = 5;
            this.btnEqual.Text = "=";
            this.btnEqual.UseVisualStyleBackColor = false;
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            // 
            // btnPlus
            // 
            this.btnPlus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPlus.Location = new System.Drawing.Point(139, 107);
            this.btnPlus.Name = "btnPlus";
            this.btnPlus.Size = new System.Drawing.Size(130, 46);
            this.btnPlus.TabIndex = 6;
            this.btnPlus.Text = "+";
            this.btnPlus.UseVisualStyleBackColor = false;
            this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this.btnMemorySave);
            this.flowLayoutPanel6.Controls.Add(this.btnMemoryRead);
            this.flowLayoutPanel6.Controls.Add(this.btnClear);
            this.flowLayoutPanel6.Location = new System.Drawing.Point(281, 177);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(411, 57);
            this.flowLayoutPanel6.TabIndex = 4;
            // 
            // btnMemorySave
            // 
            this.btnMemorySave.BackColor = System.Drawing.SystemColors.Info;
            this.btnMemorySave.Location = new System.Drawing.Point(3, 3);
            this.btnMemorySave.Name = "btnMemorySave";
            this.btnMemorySave.Size = new System.Drawing.Size(130, 46);
            this.btnMemorySave.TabIndex = 1;
            this.btnMemorySave.Text = "MS";
            this.btnMemorySave.UseVisualStyleBackColor = false;
            this.btnMemorySave.Click += new System.EventHandler(this.btnMemorySave_Click);
            // 
            // btnMemoryRead
            // 
            this.btnMemoryRead.BackColor = System.Drawing.SystemColors.Info;
            this.btnMemoryRead.Location = new System.Drawing.Point(139, 3);
            this.btnMemoryRead.Name = "btnMemoryRead";
            this.btnMemoryRead.Size = new System.Drawing.Size(130, 46);
            this.btnMemoryRead.TabIndex = 2;
            this.btnMemoryRead.Text = "MR";
            this.btnMemoryRead.UseVisualStyleBackColor = false;
            this.btnMemoryRead.Click += new System.EventHandler(this.btnMemoryRead_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.Info;
            this.btnClear.Location = new System.Drawing.Point(275, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(130, 46);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "C";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOutput.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblOutput.Location = new System.Drawing.Point(281, 55);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(693, 45);
            this.lblOutput.TabIndex = 5;
            this.lblOutput.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 448);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.flowLayoutPanel6);
            this.Controls.Add(this.flowLayoutPanel4);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnSqrt;
        private System.Windows.Forms.Button btnDivOnX;
        private System.Windows.Forms.Button btnSin;
        private System.Windows.Forms.Button btnLn;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button btnLog2;
        private System.Windows.Forms.Button btnTg;
        private System.Windows.Forms.Button btnLog10;
        private System.Windows.Forms.Button btnCtg;
        private System.Windows.Forms.Button btnSquaring;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnDot;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnPM;
        private System.Windows.Forms.Button btnMinus;
        private System.Windows.Forms.Button btnMultiplication;
        private System.Windows.Forms.Button btnEqual;
        private System.Windows.Forms.Button btnPlus;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Button btnMemorySave;
        private System.Windows.Forms.Button btnMemoryRead;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox lblOutput;
    }
}

